﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication24
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("register.aspx");
        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        protected void Button3_Click(object sender, EventArgs e)
        {


            using (DataClasses1DataContext db = new DataClasses1DataContext())
            {
                var sight1 = new Sight_();
                var sight2 = new Sight_();
                var sight3 = new Sight_();
                var sight4 = new Sight_();
                var sight5 = new Sight_();
                var sight6 = new Sight_();
                var sight7 = new Sight_();
                var sight8 = new Sight_();
                var sight9 = new Sight_();
                var sight10 = new Sight_();
                var sight11 = new Sight_();
                var sight12 = new Sight_();
              
                //var rest= new Resturant_();
                // var custom = (from C in db.customer_s
                //  where C.Phone_ == TextBox8.Text

               try
                {//   select C).Single();
                    var restaurant = (from R in db.Resturant_s
                                      join C in db.City_s on R.CityID_ equals C.CityID_
                                      where C.name_ == TextBox4.Text && R.resturantname_ == TextBox3.Text
                                      select R).Single();



                    if (CheckBox65.Checked || CheckBox66.Checked || CheckBox67.Checked)
                    {

                        sight1.QID_ = 1;
                        if (CheckBox65.Checked)
                        { sight1.SightContent_ = 1; }
                        else if (CheckBox66.Checked)
                        { sight1.SightContent_ = 2; }
                        else if (CheckBox67.Checked)
                        { sight1.SightContent_ = 3; }

                        //  sight1. = custom.id_;
                        sight1.ResturantID_ = restaurant.ID_;
                        sight1.time_ = System.DateTime.Now.ToString();

                        db.Sight_s.InsertOnSubmit(sight1);
                        db.SubmitChanges();




                    }

                    if (CheckBox68.Checked || CheckBox69.Checked || CheckBox70.Checked)
                    {

                        sight2.QID_ = 2;
                        if (CheckBox68.Checked)
                        { sight2.SightContent_ = 1; }
                        else if (CheckBox69.Checked)
                        { sight2.SightContent_ = 2; }
                        else if (CheckBox70.Checked)
                        { sight2.SightContent_ = 3; }

                        //  sight2.UserID_ = custom.id_;
                        sight2.ResturantID_ = restaurant.ID_;
                        sight2.time_ = System.DateTime.Now.ToString();

                        db.Sight_s.InsertOnSubmit(sight2);
                        db.SubmitChanges();




                    }

                    if (CheckBox71.Checked || CheckBox72.Checked || CheckBox73.Checked)
                    {

                        sight3.QID_ = 3;
                        if (CheckBox71.Checked)
                        { sight3.SightContent_ = 1; }
                        else if (CheckBox72.Checked)
                        { sight3.SightContent_ = 2; }
                        else if (CheckBox73.Checked)
                        { sight3.SightContent_ = 3; }

                        //sight3.UserID_ = custom.id_;
                        sight3.ResturantID_ = restaurant.ID_;
                        sight3.time_ = System.DateTime.Now.ToString();

                        db.Sight_s.InsertOnSubmit(sight3);
                        db.SubmitChanges();




                    }

                    if (CheckBox74.Checked || CheckBox75.Checked || CheckBox76.Checked)
                    {

                        sight4.QID_ = 4;
                        if (CheckBox74.Checked)
                        { sight4.SightContent_ = 1; }
                        else if (CheckBox75.Checked)
                        { sight4.SightContent_ = 2; }
                        else if (CheckBox76.Checked)
                        { sight4.SightContent_ = 3; }

                        //sight4.UserID_ = custom.id_;
                        sight4.ResturantID_ = restaurant.ID_;
                        sight4.time_ = System.DateTime.Now.ToString();

                        db.Sight_s.InsertOnSubmit(sight4);
                        db.SubmitChanges();

                    }

                    if (CheckBox77.Checked || CheckBox78.Checked || CheckBox79.Checked)
                    {

                        sight5.QID_ = 5;
                        if (CheckBox77.Checked)
                        { sight5.SightContent_ = 1; }
                        else if (CheckBox78.Checked)
                        { sight5.SightContent_ = 2; }
                        else if (CheckBox79.Checked)
                        { sight5.SightContent_ = 3; }

                        //sight5.UserID_ = custom.id_;
                        sight5.ResturantID_ = restaurant.ID_;
                        sight5.time_ = System.DateTime.Now.ToString();

                        db.Sight_s.InsertOnSubmit(sight5);
                        db.SubmitChanges();

                    }


                    if (CheckBox80.Checked || CheckBox81.Checked || CheckBox82.Checked)
                    {

                        sight6.QID_ = 6;
                        if (CheckBox80.Checked)
                        { sight6.SightContent_ = 1; }
                        else if (CheckBox81.Checked)
                        { sight6.SightContent_ = 2; }
                        else if (CheckBox82.Checked)
                        { sight6.SightContent_ = 3; }

                        //sight6.UserID_ = custom.id_;
                        sight6.ResturantID_ = restaurant.ID_;
                        sight6.time_ = System.DateTime.Now.ToString();

                        db.Sight_s.InsertOnSubmit(sight6);
                        db.SubmitChanges();


                    }



                    if (CheckBox83.Checked || CheckBox84.Checked || CheckBox85.Checked)
                    {

                        sight7.QID_ = 7;
                        if (CheckBox83.Checked)
                        { sight7.SightContent_ = 1; }
                        else if (CheckBox84.Checked)
                        { sight7.SightContent_ = 2; }
                        else if (CheckBox85.Checked)
                        { sight7.SightContent_ = 3; }

                        //sight7.UserID_ = custom.id_;
                        sight7.ResturantID_ = restaurant.ID_;
                        sight7.time_ = System.DateTime.Now.ToString();

                        db.Sight_s.InsertOnSubmit(sight7);
                        db.SubmitChanges();


                    }


                    if (CheckBox86.Checked || CheckBox87.Checked || CheckBox88.Checked)
                    {

                        sight8.QID_ = 8;
                        if (CheckBox86.Checked)
                        { sight8.SightContent_ = 1; }
                        else if (CheckBox87.Checked)
                        { sight8.SightContent_ = 2; }
                        else if (CheckBox88.Checked)
                        { sight8.SightContent_ = 3; }

                        //sight8.UserID_ = custom.id_;
                        sight8.ResturantID_ = restaurant.ID_;
                        sight8.time_ = System.DateTime.Now.ToString();

                        db.Sight_s.InsertOnSubmit(sight8);
                        db.SubmitChanges();


                    }


                    if (CheckBox89.Checked || CheckBox90.Checked || CheckBox91.Checked)
                    {

                        sight9.QID_ = 9;
                        if (CheckBox89.Checked)
                        { sight9.SightContent_ = 1; }
                        else if (CheckBox90.Checked)
                        { sight9.SightContent_ =2; }
                        else if (CheckBox91.Checked)
                        { sight9.SightContent_ = 3; }

                        //sight9.UserID_ = custom.id_;
                        sight9.ResturantID_ = restaurant.ID_;
                        sight9.time_ = System.DateTime.Now.ToString();

                        db.Sight_s.InsertOnSubmit(sight9);
                        db.SubmitChanges();


                    }



                    if (CheckBox92.Checked || CheckBox93.Checked || CheckBox94.Checked)
                    {

                        sight10.QID_ = 10;
                        if (CheckBox92.Checked)
                        { sight10.SightContent_ = 1; }
                        else if (CheckBox93.Checked)
                        { sight10.SightContent_ = 2; }
                        else if (CheckBox94.Checked)
                        { sight10.SightContent_ = 3; }

                        // sight10.UserID_ = custom.id_;
                        sight10.ResturantID_ = restaurant.ID_;
                        sight10.time_ = System.DateTime.Now.ToString();

                        db.Sight_s.InsertOnSubmit(sight10);
                        db.SubmitChanges();
                    }

                    if (CheckBox95.Checked || CheckBox96.Checked || CheckBox97.Checked)
                    {

                        sight11.QID_ = 11;
                        if (CheckBox95.Checked)
                        { sight11.SightContent_ = 1; }
                        else if (CheckBox96.Checked)
                        { sight11.SightContent_ = 2; }
                        else if (CheckBox97.Checked)
                        { sight11.SightContent_ = 3; }

                        //sight11.UserID_ = custom.id_;
                        sight11.ResturantID_ = restaurant.ID_;
                        sight11.time_ = System.DateTime.Now.ToString();

                        db.Sight_s.InsertOnSubmit(sight11);
                        db.SubmitChanges();


                    }


                    if (CheckBox98.Checked || CheckBox99.Checked || CheckBox100.Checked)
                    {

                        sight12.QID_ = 12;
                        if (CheckBox98.Checked)
                        { sight12.SightContent_ = 1; }
                        else if (CheckBox99.Checked)
                        { sight12.SightContent_ = 2; }
                        else if (CheckBox100.Checked)
                        { sight12.SightContent_ = 3; }

                        //sight12.UserID_ = custom.id_;
                        sight12.ResturantID_ = restaurant.ID_;
                        sight12.time_ = System.DateTime.Now.ToString();

                        db.Sight_s.InsertOnSubmit(sight12);
                        db.SubmitChanges();


                    }






                    var testvorood = (from T in db.test_voroods
                                      where T.id == 0
                                      select T).Single();
                    testvorood.value=1;

                    db.SubmitChanges();


                    //  System.Threading.Thread.Sleep(5000);


                    var rest = (from R in db.Resturant_s
                                join C in db.City_s on R.CityID_ equals C.CityID_
                                where C.name_ == TextBox4.Text && R.resturantname_== TextBox3.Text
                                select R).Single();

                    foreach (var k in db.Sight_s)
                    {
                        if (k.ResturantID_ == rest.ID_)
                        {
                            rest.ResturantRate_ = rest.ResturantRate_ + k.SightContent_;
                        }
                    }
                    db.SubmitChanges();



                    Response.Redirect("WebForm7.aspx");

                }
                catch
                {

                   string display = "اطلاعات را اشتباه وارد کرده اید";
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + display + "');", true);

                }
            } } 

        protected void CheckBox102_CheckedChanged(object sender, EventArgs e)
        {



        }

        protected void CheckBox70_CheckedChanged(object sender, EventArgs e)
        {

        }

        protected void Button4_Click(object sender, EventArgs e)
        {

        }

        protected void Button9_Click(object sender, EventArgs e)
        {
            Response.Redirect("mainpage.aspx");
        }

        protected void Button4_Click1(object sender, EventArgs e)
        {
            Response.Redirect("register.aspx");
        }

        protected void Button6_Click1(object sender, EventArgs e)
        {
            Response.Redirect("resturants.aspx");
        }

        protected void Button7_Click(object sender, EventArgs e)
        {
            Response.Redirect("news.aspx");
        }

        protected void Button8_Click1(object sender, EventArgs e)
        {
            Response.Redirect("callsme.aspx");
        }

        protected void Button10_Click1(object sender, EventArgs e)
        {
            Response.Redirect("register.aspx");
        }
    }
}