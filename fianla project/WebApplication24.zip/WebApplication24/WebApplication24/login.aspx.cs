﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication24
{
    public partial class WebForm6 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

       

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void TextBox8_TextChanged(object sender, EventArgs e)
        {

        }

        protected void TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        protected void TextBox4_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            using (DataClasses1DataContext db = new DataClasses1DataContext())
            {
                

                try
                {
                    string s;

                    s = TextBox1.Text;
                    customer_ usr1 = db.customer_s.Where(c => c.id_ == TextBox1.Text && c.Password_== TextBox8.Text).Single();
                    if (usr1 != null)
                    {
                       

                        string message = "شما با موفقیت وارد شدید";
                        string script = "window.onload = function(){ alert('";
                        script += message;
                        script += "')};";
                        ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", script, true);

                        //code of submit change of sightsv  sight.aspx
                        var testvorood = (from T in db.test_voroods
                                          where T.id == 0
                                          select T).Single();
                        testvorood.value=2;
                  
                        db.SubmitChanges();


                    }
                }
               catch (Exception)
                {
                    string message = "رمز عبور یا نام کاربری اشتباه است";
                    string script = "window.onload = function(){ alert('";
                    script += message;
                    script += "')};";
                    ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", script, true);
                }

              

        }

        }

        protected void Button4_Click(object sender, EventArgs e)
        {

            using (DataClasses1DataContext db = new DataClasses1DataContext())
            {
                var vorood = (from R in db.test_voroods
                              where R.id == 0
                              select R).Single();
                if (vorood.value == 1)
                {
                    string display = "کاربر عزیز شما ابتدا باید وارد شوید درصورتی که ثبت نام نکرده اید ابتدا ثبت نام کنید و سپس وارد شوید  :(";
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + display + "');", true);
                }
                else
                {

                    Response.Redirect("sight.aspx");

                }
            }











        }

        protected void Button9_Click(object sender, EventArgs e)
        {
            Response.Redirect("mainpage.aspx");
        }

        protected void Button4_Click1(object sender, EventArgs e)
        {
            using (DataClasses1DataContext db = new DataClasses1DataContext())
            {
                var vorood = (from R in db.test_voroods
                              where R.id == 0
                              select R).Single();
                if (vorood.value == 1)
                {
                    string display = "کاربر عزیز شما ابتدا باید وارد شوید درصورتی که ثبت نام نکرده اید ابتدا ثبت نام کنید و سپس وارد شوید  :(";
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + display + "');", true);
                }
                else
                {

                    Response.Redirect("sight.aspx");

                }
            }
        }

        protected void Button6_Click1(object sender, EventArgs e)
        {
            Response.Redirect("resturants.aspx");
        }

        protected void Button7_Click(object sender, EventArgs e)
        {
            Response.Redirect("news.aspx");
        }

        protected void Button8_Click1(object sender, EventArgs e)
        {
            Response.Redirect("callsme.aspx");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("register.aspx");
        }

        protected void Button10_Click1(object sender, EventArgs e)
        {
            Response.Redirect("login.aspx");
        }
    }
}