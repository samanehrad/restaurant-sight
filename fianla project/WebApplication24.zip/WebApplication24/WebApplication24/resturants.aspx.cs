﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication24
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            DataClasses1DataContext db = new DataClasses1DataContext();
            var res = from u in db.Resturant_s
                      orderby u.ResturantRate_ descending
                      select new
                      {

                          u.ResturantRate_,
                          u.resturanttype_,
                          u.resturantaddress_,
                          u.resturantname_

                      };
            GridView1.DataSource = res;
            GridView1.DataBind();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("register.aspx");
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            using (DataClasses1DataContext db = new DataClasses1DataContext())
            {
                var res = from u in db.Resturant_s
                          where (u.resturantname_ == TextBox5.Text)
                          select new
                          {

                              u.ResturantRate_,
                              u.resturanttype_,
                              u.resturantaddress_,
                              u.resturantname_
                          };
                if (res.Count() == 0)
                {


                    string message = "چنین رستورانی وجود ندارد";
                    string script = "window.onload = function(){ alert('";
                    script += message;
                    script += "')};";
                    ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", script, true);


                }
                else
                {
                    GridView1.DataSource = res;
                    GridView1.DataBind();
                }
            }
        }

        protected void Button4_Click(object sender, EventArgs e)
        {



            using (DataClasses1DataContext db = new DataClasses1DataContext())
            {
                var res = from u in db.Resturant_s
                          join t in db.City_s on u.CityID_ equals t.CityID_
                          where (t.name_ == TextBox6.Text)
                          select new
                          {

                              u.ResturantRate_,
                              u.resturanttype_,
                              u.resturantaddress_,
                              u.resturantname_
                          };
                GridView1.DataSource = res;
                GridView1.DataBind();
            }
        }

        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                e.Row.Cells[0].Text = "امتیاز رستوران";
                e.Row.Cells[1].Text = "نوع رستوران";
                e.Row.Cells[2].Text = "آدرس رستوران";
                e.Row.Cells[3].Text = "نام رستوران";
            }
        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            using (DataClasses1DataContext db = new DataClasses1DataContext())
            {
                var res1 = from u in db.Resturant_s
                           where (u.resturantname_ == TextBox5.Text)
                           select new
                           {

                               u.ResturantRate_,
                               u.resturanttype_,
                               u.resturantaddress_,
                               u.resturantname_
                           };

                if (res1.Count() == 0)
                {


                    string message = "چنین رستورانی وجود ندارد";
                    string script = "window.onload = function(){ alert('";
                    script += message;
                    script += "')};";
                    ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", script, true);


                }
                else
                {
                    GridView1.DataSource = res1;
                    GridView1.DataBind();
                }
            }
        }

        protected void TextBox5_TextChanged(object sender, EventArgs e)
        {

        }

        protected void TextBox6_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button10_Click1(object sender, EventArgs e)
        {
            Response.Redirect("login.aspx");
        }

        protected void Button9_Click(object sender, EventArgs e)
        {
            Response.Redirect("mainpage.aspx");
        }

        protected void Button4_Click1(object sender, EventArgs e)
        {


            using (DataClasses1DataContext db = new DataClasses1DataContext())
            {
                var vorood = (from R in db.test_voroods
                              where R.id == 0
                              select R).Single();
                if (vorood.value == 1)
                {
                    string display = "کاربر عزیز شما ابتدا باید وارد شوید درصورتی که ثبت نام نکرده اید ابتدا ثبت نام کنید و سپس وارد شوید  :(";
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + display + "');", true);
                }
                else
                {

                    Response.Redirect("sight.aspx");

                }
            }







        }

        protected void Button6_Click1(object sender, EventArgs e)
        {
            Response.Redirect("resturants.aspx");

        }

        protected void Button7_Click(object sender, EventArgs e)
        {
            Response.Redirect("news.aspx");
        }

        protected void Button8_Click1(object sender, EventArgs e)
        {
            Response.Redirect("callsme.aspx");
        }

        protected void Button12_Click(object sender, EventArgs e)
        {
            using (DataClasses1DataContext db = new DataClasses1DataContext())
            {
                var res = from u in db.Resturant_s
                          join t in db.City_s on u.CityID_ equals t.CityID_
                          where (t.name_ == TextBox6.Text)
                          select new
                          {

                              u.ResturantRate_,
                              u.resturanttype_,
                              u.resturantaddress_,
                              u.resturantname_
                          };
                if (res.Count() == 0)
                {


                    string message = "چنین شهری وجود ندارد";
                    string script = "window.onload = function(){ alert('";
                    script += message;
                    script += "')};";
                    ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", script, true);


                }
                else
                {
                    GridView1.DataSource = res;
                    GridView1.DataBind();
                }

            }
        }
    }
}

