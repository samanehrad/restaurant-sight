﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication24
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("register.aspx");
        }

      

        protected void Button10_Click(object sender, EventArgs e)
        {
            Response.Redirect("login.aspx");
        }

        protected void Button9_Click(object sender, EventArgs e)
        {
            Response.Redirect("mainpage.aspx");
        }

        protected void Button4_Click1(object sender, EventArgs e)
        {
            using (DataClasses1DataContext db = new DataClasses1DataContext())
            {
                var vorood = (from R in db.test_voroods
                              where R.id == 0
                              select R).Single();
                if (vorood.value == 1)
                {
                    string display = "کاربر عزیز شما ابتدا باید وارد شوید درصورتی که ثبت نام نکرده اید ابتدا ثبت نام کنید و سپس وارد شوید  :(";
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + display + "');", true);
                }
                else
                {

                    Response.Redirect("sight.aspx");

                }
            }




        }

        protected void Button6_Click1(object sender, EventArgs e)
        {
            Response.Redirect("resturants.aspx");
        }

        protected void Button7_Click(object sender, EventArgs e)
        {
            Response.Redirect("news.aspx");
        }

        protected void Button8_Click1(object sender, EventArgs e)
        {
            Response.Redirect("callsme.aspx");
        }

        protected void Button10_Click1(object sender, EventArgs e)
        {
            Response.Redirect("login.aspx");
        }
    }
}