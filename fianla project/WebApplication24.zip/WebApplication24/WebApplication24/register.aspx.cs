﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication24
{
    public partial class register : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("register.aspx");
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            using (DataClasses1DataContext db = new DataClasses1DataContext())
            {
                try
                {
                    if (string.IsNullOrWhiteSpace(TextBox1.Text ) || string.IsNullOrWhiteSpace(TextBox2.Text) || string.IsNullOrWhiteSpace(TextBox4.Text) || string.IsNullOrWhiteSpace(TextBox8.Text) || string.IsNullOrWhiteSpace(TextBox9.Text) || string.IsNullOrWhiteSpace(TextBox10.Text))
                    {
                        string message2 = "اطلاعات کامل نمی باشند ";
                        string script2 = "window.onload = function(){ alert('";
                        script2 += message2;
                        script2 += "')};";
                        ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", script2, true);


                    }

                    else
                    {
                        if (TextBox8.Text.Length < 11)
                        {
                            string message2 = "شماره تلفن صحیح نمی باشد ";
                            string script2 = "window.onload = function(){ alert('";
                            script2 += message2;
                            script2 += "')};";
                            ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", script2, true);


                        }

                        else
                        {
                            if (TextBox4.Text.Length < 6)
                            {


                                string message2 = "رمز عبور صحیح نمی باشد ";
                                string script2 = "window.onload = function(){ alert('";
                                script2 += message2;
                                script2 += "')};";
                                ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", script2, true);



                            }

                            var res = from u in db.customer_s
                                      where (u.Password_== TextBox4.Text)
                                      select new
                                      {

                                         
                                      };
                            if (res.Count() != 0)
                            {


                                string message = "این رمز ورود قبلا ثبت شده است";
                                string script = "window.onload = function(){ alert('";
                                script += message;
                                script += "')};";
                                ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", script, true);


                            }

                            else
                            {
                                customer_ u1 = new customer_
                                {

                                    name_ = TextBox1.Text,
                                    family_ = TextBox10.Text,

                                    Phone_ = TextBox8.Text,
                                    Email_ = TextBox2.Text,
                                    id_ = TextBox9.Text,
                                    Password_ = TextBox4.Text


                                };

                                db.customer_s.InsertOnSubmit(u1);
                                db.SubmitChanges();
                                string message = "ثبت نام شما با موفقیت انجام شد";
                                string script = "window.onload = function(){ alert('";
                                script += message;
                                script += "')};";
                                ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", script, true);
                            }
                        }

                    }
                }

                catch (Exception)
                {
                    string message = "اطلاعات وارد شده صحیح نمی باشد ";
                    string script = "window.onload = function(){ alert('";
                    script += message;
                    script += "')};";
                    ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", script, true);
                }
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {

        }

        protected void Button8_Click(object sender, EventArgs e)
        {
            Response.Redirect("news.aspx");
        }

        protected void Button4_Click(object sender, EventArgs e)
        {

            using (DataClasses1DataContext db = new DataClasses1DataContext())
            {
                var vorood = (from R in db.test_voroods
                              where R.id == 0
                              select R).Single();
                if (vorood.value == 1)
                {
                    string display = "کاربر عزیز شما ابتدا باید وارد شوید درصورتی که ثبت نام نکرده اید ابتدا ثبت نام کنید و سپس وارد شوید  :(";
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + display + "');", true);
                }
                else
                {

                    Response.Redirect("sight.aspx");

                }
            }





        }

        protected void Button6_Click(object sender, EventArgs e)
        {

            Response.Redirect("callsme.aspx");
        }

        protected void Button8_Click1(object sender, EventArgs e)
        {
            Response.Redirect("callsme.aspx");
        }

        protected void Button9_Click(object sender, EventArgs e)
        {
            Response.Redirect("mainpage.aspx");
        }

        protected void Button4_Click1(object sender, EventArgs e)
        {


            using (DataClasses1DataContext db = new DataClasses1DataContext())
            {
                var vorood = (from R in db.test_voroods
                              where R.id == 0
                              select R).Single();
                if (vorood.value == 1)
                {
                    string display = "کاربر عزیز شما ابتدا باید وارد شوید درصورتی که ثبت نام نکرده اید ابتدا ثبت نام کنید و سپس وارد شوید  :(";
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + display + "');", true);
                }
                else
                {

                    Response.Redirect("sight.aspx");

                }
            }


        }

        protected void Button6_Click1(object sender, EventArgs e)
        {
            Response.Redirect("resturants.aspx");
        }

        protected void Button7_Click(object sender, EventArgs e)
        {
            Response.Redirect("news.aspx");
        }

        protected void Button10_Click(object sender, EventArgs e)
        {
            Response.Redirect("login.aspx");
        }

        protected void Button10_Click1(object sender, EventArgs e)
        {
            Response.Redirect("login.aspx");
        }
    }
}
